﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication6
{
    class Program
    {
        static void Main(string[] args)
        {
            var dept1 = new Department() { DepartmentId = 1, DepartmentName = "HR" };
            var dept2 = new Department() { DepartmentId = 2, DepartmentName = "Accounts" };
            var dept3 = new Department() { DepartmentId = 3, DepartmentName = "Technical" };


            IList<Department> deptList = new List<Department>() { 
                                                    dept1, 
                                                    dept2, 
                                                    dept3,                                                     
                                                };

            var emp1 = new Employee() { EmployeeId = 1, EmployeeName = "Raj", DepartmentId = 1};
            var emp2 = new Employee() { EmployeeId = 2, EmployeeName = "Deep", DepartmentId=2};
            var emp3 = new Employee() { EmployeeId = 3, EmployeeName = "Vijay", DepartmentId=1};
            var emp4 = new Employee() { EmployeeId = 3, EmployeeName = "Ganesh" ,DepartmentId=2};
            var emp5 = new Employee() { EmployeeId = 3, EmployeeName = "Ankush" ,DepartmentId=1};
            var emp6 = new Employee() { EmployeeId = 3, EmployeeName = "Neeraj" };


            IList<Employee> employeeList = new List<Employee>() { 
                                                    emp1, 
                                                    emp2, 
                                                    emp3,emp4,emp5,emp6                                                     
                                                };

            //Inner join using linq


            var result = from emp in employeeList
                         join dept in deptList
                         on emp.DepartmentId equals dept.DepartmentId
                         select new 
                         {
                             EmployeeName = emp.EmployeeName,
                             DepartmentName = dept.DepartmentName

                         };

            foreach (var employee in result)
            {
                Console.WriteLine(employee.EmployeeName + "\t" + employee.DepartmentName);
            }

            var result1  = employeeList.Join(deptList, 
                                           emp => emp.DepartmentId,
                                           dept => dept.DepartmentId,
                                           (Employee,department) => new
                                           {
                                               EmployeeName = Employee.EmployeeName,
                                               DepartmentName = department.DepartmentName,

                                           }) ;

            Console.WriteLine();
            foreach (var employee in result1)
            {
                Console.WriteLine(employee.EmployeeName + "\t" + employee.DepartmentName);
            }


            //Left JOin

            Console.WriteLine();
            var leftJoinResult = from emp in employeeList
                                 join dept in deptList
                                 on emp.DepartmentId equals dept.DepartmentId into newGroup
                                 from dept in newGroup.DefaultIfEmpty()
                                 select new
                                     {
                                         EmployeeName = emp.EmployeeName,
                                         DepartmentName = dept ==null ? "Default" : dept.DepartmentName,

                                     };

            foreach (var employee in leftJoinResult)
            {
                Console.WriteLine(employee.EmployeeName + "\t" + employee.DepartmentName);
            }

            Console.WriteLine();

            var LeftJoinResult = employeeList.GroupJoin(deptList,
                                           emp => emp.DepartmentId,
                                           dept => dept.DepartmentId,
                                           (Employee, department) => new
                                           {
                                               Employee ,
                                               department 
                                           }).SelectMany( x=>x.department.DefaultIfEmpty(), 
                                           (a,b)=> new {
                                               EmployeeName = a.Employee.EmployeeName,
                                               DepartmentName = b == null ? "Default" : b.DepartmentName,
                                           
                                           });

            foreach (var employee in LeftJoinResult)
            {
                Console.WriteLine(employee.EmployeeName + "\t" + employee.DepartmentName);
            }

            Console.ReadLine();


        }
    }

    class Department
    {
        public int DepartmentId;
        public string DepartmentName;
    }
    class Employee
    {
        public int EmployeeId;
        public string EmployeeName;
        public int DepartmentId;
    }
}
