﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ArrayManipulation
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("How Many Elements in an Array");
            int N = int.Parse(Console.ReadLine());

            int[] array = new int[N];

            Console.WriteLine("Please Enter Elements of an Array");

            for (int i = 0; i < N; i++)
            {
                array[i] = int.Parse(Console.ReadLine());
            }

            Console.WriteLine("Enter A");
            int A = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter B");
            int B = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter C");
            int C = int.Parse(Console.ReadLine());

            DivideArray(array, A, B, C, N);
        }
        //Arr[0,A-1], Arr[A,B], Arr[B+1, C], and Arr[C+1, N-1])

        static void DivideArray(int[] array , int A , int B , int C ,int N)
        {
            int[] Array1 = new int[A];
            int[] Array2 = new int[B - A + 1 ];
            int[] Array3 = new int[C-B];
            int[] Array4 = new int[(N) - ( C + 1)];
            for (int i = 0; i <= A - 1; i++)
            {
                Array1[i] = array[i];
            }

            int x = 0;
            for (int i = A; i <= B; i++)
            {
                Array2[x] = array[i];
                x++;
            }

            x = 0;
            for (int i = B+1; i <= C; i++)
            {
                Array3[x] = array[i];
                x++;
            }

            x = 0;
            for (int i = C + 1; i <= N-1; i++)
            {
                Array4[x] = array[i];
                x++;
            }

            int temp = 0;
            for (int i = 0; i < Array1.Length;i++ )
            {
                temp = Array1[i];
                if (i < Array2.Length)
                {
                    Array1[i] = Array2[i];
                    Array2[i] = temp;
                }
            }

            temp = 0;
            for (int i = 0; i < Array3.Length; i++)
            {
                temp = Array3[i];
                if (i < Array4.Length)
                {
                    Array3[i] = Array4[i];
                    Array4[i] = temp;
                }
            }


            int [] newArray = new int[N] ;

            for (int i = 0; i < Array1.Length; i++)
            {
                newArray[i] = Array1[i];
            }

            temp = Array1.Length;


            for (int i = 0; i < Array2.Length; i++)
            {
                newArray[temp] = Array2[i];
                temp++;
            }

            temp = Array1.Length + Array2.Length;
            for (int i = 0; i < Array3.Length; i++)
            {
                newArray[temp] = Array3[i];
                temp++;
            }

            temp = Array1.Length + Array2.Length + Array3.Length;
            for (int i = 0; i < Array4.Length; i++)
            {
                newArray[temp] = Array4[i];
                temp++;
            }

            foreach (int i in newArray)
            {
                Console.WriteLine(i);
            }

            Console.ReadLine();
            
        }
    }
}
